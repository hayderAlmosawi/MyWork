from __future__ import unicode_literals

from django.db import models

# Create your models here.


class Student(models.Model):
    StudentName = models.CharField(max_length=50)
    SurName = models.CharField(max_length=50)
    UniversityLevel = models.IntegerField()
    Gender = models.CharField(max_length=45)
    Address = models.CharField(max_length=50)
    BirthDate = models.DateField()
    Phone = models.CharField(max_length=20)
    Subject_id = models.ForeignKey('Subject', on_delete=models.CASCADE)
    Department_id = models.ForeignKey('Department' , on_delete = models.CASCADE)
    #Marks_id = models.ForeignKey('Marks',on_delete=models.CASCADE)


    def __unicode__(self):
        return self.StudentName




class Subject(models.Model):
    SubjectName = models.CharField(max_length=50)
    UniversityLevel = models.IntegerField()
    SubjectTime = models.TimeField()
    ClassRoom = models.IntegerField()
    Day = models.CharField(max_length=20)
    Student_id = models.ForeignKey(Student,on_delete=models.CASCADE)

    def __unicode__(self):
        return self.SubjectName





class Marks(models.Model):
    Student_id = models.ForeignKey(Student,on_delete=models.CASCADE)
    Subject_id = models.ForeignKey(Subject,on_delete=models.CASCADE)
    FirstCourse=models.IntegerField()
    SecondCourse=models.IntegerField()
    Average=models.IntegerField()
    FinalExam=models.IntegerField()
    Result=models.CharField(max_length=20)

    def __int__(self):
        return self.Student_id




class Department(models.Model):

    DepartmentName = models.CharField(max_length=50)

    def __str__(self):
        return self.DepartmentName



class Teacher(models.Model):

    TeacherName = models.CharField(max_length=50)
    SurName = models.CharField(max_length=50)
    AcademicTitle = models.CharField(max_length=50)
    Address = models.CharField(max_length=50)
    Phone = models.CharField(max_length=20)
    Specialty_id = models.ForeignKey('Specialty' , on_delete=models.CASCADE)

    def __unicode__(self):
        return self.TeacherName





class Specialty(models.Model):

    Specialty = models.CharField(max_length=50)

    def __unicode__(self):
        return self.Specialty




class ScientificResearch(models.Model):
    Teacher_id = models.ForeignKey(Teacher ,on_delete=models.CASCADE,null=True)
    ResearchTitle = models.CharField(max_length=100)

    def __unicode__(self):
        return self.ResearchTitle




#class Teacher_Subject(models.Model):
 #   ID = models.primary_key=True
  #  Subject = models.ForeignKey(Subject,on_delete=models.CASCADE)
   # Teacher = models.ForeignKey(Teacher,on_delete=models.CASCADE)









