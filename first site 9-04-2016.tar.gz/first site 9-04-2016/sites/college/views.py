from django.shortcuts import render
from college import models

# Create your views here.

def home(request):
    return render(request,"home.html",{})


def student(request):
    student= models.Student.objects.all()
    context = { 'student': student}
    return render(request,"student.html",context)


def teacher(request):
    teacher = models.Teacher.objects.all()
    context = { 'teacher' : teacher}
    return render(request,"teacher.html",context)



def mark(request,Student_id):                                                           #,Student_id
    marks = models.Marks.objects.filter(Student_id=Student_id)                    # filter(Student_id=Student_id)
    context = {'marks':marks}
    return render(request, "mark.html" , context)

def research(request):
    research = models.ScientificResearch.objects.all()
    context = { 'research' : research}
    return render(request,"research.html" , context)


def about(request):
    return render(request, "about.html" , {})


def department(request):
    department = models.Department.objects.all()
    context = { 'department' : department }
    return render(request , "department.html" ,context)


def lecture(request):
    lecture = models.Subject.objects.all().filter(UniversityLevel__icontains=1)
    context = { 'lecture' : lecture}
    return render(request , "lecture.html" , context)


def photo(request):
    return render(request,"photo.html" , {})