from django.contrib import admin

# Register your models here.

from .models import Marks,Subject,Department,Student,Specialty,ScientificResearch,Teacher

admin.site.register(Marks)
admin.site.register(Subject)
admin.site.register(Department)
admin.site.register(Student)
admin.site.register(Specialty)
admin.site.register(ScientificResearch)
admin.site.register(Teacher)
#admin.site.register(Teacher_Subject)

